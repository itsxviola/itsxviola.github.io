import { useState } from "react";
import { ChevronLeft, ChevronRight, Headphones, Piano, RotateCcw, Volume2, Waves } from "lucide-react";

type KeySpec = { label: string; key: string };

const whiteKeys: KeySpec[] = [
  { label: "C4", key: "A" }, { label: "D4", key: "S" }, { label: "E4", key: "D" },
  { label: "F4", key: "F" }, { label: "G4", key: "G" }, { label: "A4", key: "H" },
  { label: "B4", key: "J" }, { label: "C5", key: "K" }, { label: "D5", key: "L" }, { label: "E5", key: ";" },
];

const blackKeys = [
  { label: "C#4", key: "W", left: "10%" }, { label: "D#4", key: "E", left: "20%" },
  { label: "F#4", key: "T", left: "40%" }, { label: "G#4", key: "Y", left: "50%" },
  { label: "A#4", key: "U", left: "60%" }, { label: "C#5", key: "O", left: "80%" },
  { label: "D#5", key: "P", left: "90%" },
];

export function WarmListeningRoom() {
  const [octave, setOctave] = useState(4);
  const [active, setActive] = useState<string[]>([]);
  const [lastNote, setLastNote] = useState("—");
  const [volume, setVolume] = useState(68);
  const [started, setStarted] = useState(false);
  const [sustain, setSustain] = useState(false);
  const play = (key: string, label: string) => {
    setStarted(true);
    setLastNote(label.replace("4", String(octave)));
    setActive((current) => current.includes(key) ? current : [...current, key]);
    if (!sustain) window.setTimeout(() => setActive((current) => current.filter((item) => item !== key)), 420);
  };

  return (
    <main className="warm-room">
      <style>{`
        .warm-room{--ink:#332c29;--muted:#82736a;--line:rgba(71,54,43,.18);--clay:#b4583b;--honey:#df9b4b;--cream:#f7efdf;min-height:100vh;background:#e8d4bb;color:var(--ink);font-family:"DM Sans",ui-sans-serif,sans-serif;padding:0 30px 34px;overflow:hidden}
        .warm-room *{box-sizing:border-box}.wr-shell{max-width:1240px;margin:auto}.wr-mono{font-family:"Space Mono",ui-monospace,monospace;letter-spacing:.13em;text-transform:uppercase}
        .wr-header{height:78px;border-bottom:1px solid var(--line);display:flex;align-items:center;justify-content:space-between}.wr-brand{display:flex;align-items:center;gap:12px}.wr-mark{width:36px;height:36px;display:grid;place-items:center;background:#493b34;color:#edbd71;border-radius:50% 50% 50% 8px;transform:rotate(-10deg)}.wr-brand-name{font:700 14px "DM Sans",sans-serif;letter-spacing:-.04em}.wr-brand-meta{font-size:8px;color:#907c6d;margin-top:4px}.wr-status{font-size:9px;color:#897467;display:flex;gap:8px;align-items:center}.wr-status i{width:7px;height:7px;border-radius:50%;background:#bb8063;display:block}.wr-status.live i{background:#6e8866}
        .wr-hero{display:grid;grid-template-columns:1fr 294px;gap:52px;align-items:end;padding:69px 0 52px}.wr-kicker{color:var(--clay);font-size:10px;display:flex;align-items:center;gap:12px}.wr-kicker:before{content:"";height:1px;width:34px;background:var(--clay)}.wr-title{font-family:"Instrument Serif",Georgia,serif;font-size:clamp(54px,7vw,96px);font-weight:400;line-height:.88;letter-spacing:-.065em;margin:18px 0 24px}.wr-title em{color:var(--clay);font-style:italic}.wr-copy{color:var(--muted);font-size:14px;line-height:1.75;max-width:445px}
        .wr-note{min-height:195px;border-radius:22px 22px 22px 6px;background:#493b34;color:#ecc080;padding:20px 22px;position:relative;overflow:hidden;box-shadow:0 16px 28px rgba(75,51,37,.18)}.wr-note:before,.wr-note:after{content:"";position:absolute;border:1px solid rgba(236,192,128,.27);border-radius:50%;width:172px;height:172px;right:-62px;top:-54px}.wr-note:after{width:102px;height:102px;right:-1px;top:-17px}.wr-note-top{font-size:9px;color:rgba(236,192,128,.65);display:flex;justify-content:space-between}.wr-note-top b{font-weight:400;color:#db9670}.wr-current{position:relative;margin-top:57px;display:flex;align-items:baseline;gap:11px}.wr-current strong{font:400 86px/.7 "Instrument Serif",Georgia,serif;letter-spacing:-.1em}.wr-current span{font:11px "Space Mono",monospace;color:rgba(236,192,128,.62)}
        .wr-instrument{background:rgba(250,244,232,.78);border:1px solid var(--line);border-radius:24px;padding:21px 21px 17px;box-shadow:0 11px 28px rgba(100,68,42,.09)}.wr-toolbar{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--line);padding:0 5px 18px}.wr-label{font-size:9px;color:#927f70}.wr-range{font-weight:700;font-size:18px;letter-spacing:-.05em;margin-top:7px}.wr-controls{display:flex;align-items:center;gap:18px}.wr-volume{color:#8c7c6f;display:flex;align-items:center;gap:8px}.wr-volume input{width:91px;accent-color:var(--clay)}.wr-release{display:flex;align-items:center;gap:6px;background:transparent;border:1px solid var(--line);border-radius:10px;color:#8c7c6f;padding:9px 11px;font:9px "Space Mono",monospace;cursor:pointer}.wr-release:hover{border-color:var(--clay);color:var(--clay)}
        .wr-keyboard{height:226px;position:relative;display:grid;grid-template-columns:repeat(10,1fr);margin:20px 3px 18px;touch-action:none}.wr-key{cursor:pointer;user-select:none;position:relative;border:1px solid #c6ad91;border-top-color:#fff9ed;background:linear-gradient(108deg,#efe2ce,#fffaf0 48%,#ddc8ad);box-shadow:inset 0 -14px 17px rgba(112,76,48,.09),0 4px 0 rgba(103,71,48,.26);transition:transform .1s,background .12s}.wr-key:first-child{border-radius:10px 0 0 10px}.wr-key:nth-child(10){border-radius:0 10px 10px 0}.wr-key:hover{background:#f8e7c8}.wr-key.on{transform:translateY(4px);background:#e8ad5b;box-shadow:inset 0 -5px 10px rgba(137,76,23,.18),0 1px 0 rgba(99,78,47,.25)}.wr-key-label{position:absolute;bottom:29px;left:50%;transform:translateX(-50%);font:10px "Space Mono",monospace;color:#836e60}.wr-key-letter{position:absolute;bottom:10px;left:50%;transform:translateX(-50%);font:10px "Space Mono",monospace;color:#ad9782}.wr-black{position:absolute;z-index:2;top:0;width:6.2%;height:61%;transform:translateX(-50%);border:1px solid #2e2521;border-top-color:#766254;border-radius:0 0 8px 8px;background:linear-gradient(100deg,#302722,#574840 52%,#28201c);box-shadow:inset 3px 0 3px rgba(255,255,255,.08),0 6px 4px rgba(58,39,27,.3)}.wr-black:hover{background:#695449}.wr-black.on{transform:translate(-50%,4px);background:#ad5038}.wr-black .wr-key-label{top:11px;bottom:auto;color:rgba(255,247,231,.72);font-size:9px}
        .wr-footbar{border-top:1px solid var(--line);padding:15px 5px 0;display:flex;justify-content:space-between;gap:12px;color:#8c7c6f;font-size:8px}.wr-footbar b{color:var(--ink);font-weight:400}.wr-lower{display:grid;grid-template-columns:1fr 315px;gap:20px;margin-top:18px}.wr-card{border:1px solid var(--line);border-radius:19px;padding:20px;background:rgba(250,244,232,.43)}.wr-card h2{font:400 25px/1.05 "Instrument Serif",Georgia,serif;margin:9px 0;color:#4b3b31;letter-spacing:-.04em}.wr-card p{font-size:13px;line-height:1.65;color:var(--muted);max-width:520px;margin:0}.wr-shift{background:#dbc0a1;display:flex;align-items:center;justify-content:space-between}.wr-shift strong{font-size:15px}.wr-shift small{display:block;margin-top:5px;color:#897263;font:8px "Space Mono",monospace;text-transform:uppercase;letter-spacing:.13em}.wr-arrows{display:flex;gap:7px}.wr-arrows button{width:39px;height:39px;border:1px solid rgba(71,54,43,.2);border-radius:11px;background:rgba(250,244,232,.72);display:grid;place-items:center;color:var(--ink);cursor:pointer}.wr-arrows button:hover{color:var(--clay);border-color:var(--clay)}.wr-arrows button:disabled{opacity:.35;cursor:not-allowed}.wr-sustain{border:0;background:transparent;color:#8c7c6f;cursor:pointer;font:8px "Space Mono",monospace;text-transform:uppercase;letter-spacing:.1em;display:flex;align-items:center;gap:7px}.wr-sustain.active{color:var(--clay)}
        @media(max-width:760px){.warm-room{padding:0 16px 25px}.wr-header{height:68px}.wr-status{font-size:8px}.wr-hero{grid-template-columns:1fr;gap:28px;padding:46px 0 34px}.wr-title{font-size:clamp(55px,16vw,78px)}.wr-note{min-height:165px}.wr-current{margin-top:41px}.wr-current strong{font-size:72px}.wr-toolbar{align-items:flex-start;gap:15px;flex-direction:column}.wr-controls{width:100%;justify-content:space-between}.wr-keyboard{height:190px;min-width:610px}.wr-instrument{overflow-x:auto}.wr-lower{grid-template-columns:1fr}.wr-footbar{flex-direction:column}.wr-copy{font-size:13px}}
      `}</style>
      <div className="wr-shell">
        <header className="wr-header">
          <div className="wr-brand"><div className="wr-mark"><Piano size={17} strokeWidth={1.8} /></div><div><div className="wr-brand-name">the listening room</div><div className="wr-brand-meta wr-mono">warm keys / 02</div></div></div>
          <div className={`wr-status ${started ? "live" : ""}`}><i />{started ? "room is listening" : "tap a key to begin"}</div>
        </header>
        <section className="wr-hero">
          <div><div className="wr-kicker wr-mono">A softer place to practice</div><h1 className="wr-title">Stay with the note<br /><em>a little longer.</em></h1><p className="wr-copy">A small, warm browser piano for the space between hearing an idea and giving it a shape. No account, no setup — just sound.</p></div>
          <aside className="wr-note"><div className="wr-note-top wr-mono"><span>current note</span><b>{started ? "live" : "idle"}</b></div><div className="wr-current"><strong>{lastNote.replace(/[0-9]/g, "")}</strong><span>{lastNote === "—" ? "" : lastNote.slice(-1)}</span></div></aside>
        </section>
        <section className="wr-instrument">
          <div className="wr-toolbar"><div><div className="wr-label wr-mono">The instrument · felt piano</div><div className="wr-range">C{octave} — E{octave + 1}</div></div><div className="wr-controls"><label className="wr-volume"><Volume2 size={15} /><input aria-label="Volume" type="range" min="0" max="100" value={volume} onChange={(e) => setVolume(Number(e.target.value))} /></label><button className={`wr-sustain ${sustain ? "active" : ""}`} type="button" onClick={() => setSustain((value) => !value)}><Waves size={13} /> {sustain ? "sustain on" : "sustain"}</button><button className="wr-release" type="button" onClick={() => { setActive([]); setLastNote("—"); setStarted(false); }}><RotateCcw size={12} /> Release</button></div></div>
          <div className="wr-keyboard">{whiteKeys.map((item) => <button className={`wr-key ${active.includes(item.key) ? "on" : ""}`} key={item.key} type="button" onPointerDown={() => play(item.key, item.label)} aria-label={`Play ${item.label}`}><span className="wr-key-label">{item.label}</span><span className="wr-key-letter">{item.key}</span></button>)}{blackKeys.map((item) => <button className={`wr-key wr-black ${active.includes(item.key) ? "on" : ""}`} style={{ left: item.left }} key={item.key} type="button" onPointerDown={() => play(item.key, item.label)} aria-label={`Play ${item.label}`}><span className="wr-key-label">{item.key}</span></button>)}</div>
          <div className="wr-footbar wr-mono"><span><b>A S D F G H J K L ;</b> white keys <span>/</span> <b>W E T Y U O P</b> black keys</span><span><Headphones size={12} style={{ verticalAlign: "middle", marginRight: 7 }} /> press and hold to sustain</span></div>
        </section>
        <section className="wr-lower"><div className="wr-card"><div className="wr-label wr-mono">A note on listening</div><h2>Leave a little space around the sound.</h2><p>Start with middle C. Let the amber key settle under your finger, then follow its shape across the room. The small letter is its computer-key twin.</p></div><div className="wr-card wr-shift"><div><div className="wr-label wr-mono">Move the room</div><strong>Octave {octave}</strong><small>range shift</small></div><div className="wr-arrows"><button type="button" aria-label="Lower octave" disabled={octave <= 2} onClick={() => setOctave((value) => Math.max(2, value - 1))}><ChevronLeft size={17} /></button><button type="button" aria-label="Raise octave" disabled={octave >= 6} onClick={() => setOctave((value) => Math.min(6, value + 1))}><ChevronRight size={17} /></button></div></div></section>
        <footer className="wr-footbar wr-mono" style={{ marginTop: 28 }}><span>For the in-between moments</span><span>Web Audio / 12-tone equal temperament</span></footer>
      </div>
    </main>
  );
}

export default WarmListeningRoom;