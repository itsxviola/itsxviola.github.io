import { useMemo, useState } from "react";
import { ChevronLeft, ChevronRight, Headphones, Piano, RotateCcw, Volume2 } from "lucide-react";

type KeySpec = { label: string; key: string; black?: boolean };

const whiteKeys: KeySpec[] = [
  { label: "C4", key: "A" }, { label: "D4", key: "S" }, { label: "E4", key: "D" },
  { label: "F4", key: "F" }, { label: "G4", key: "G" }, { label: "A4", key: "H" },
  { label: "B4", key: "J" }, { label: "C5", key: "K" }, { label: "D5", key: "L" }, { label: "E5", key: ";" },
];

const blackKeys: { label: string; key: string; left: string }[] = [
  { label: "C#4", key: "W", left: "10%" }, { label: "D#4", key: "E", left: "20%" },
  { label: "F#4", key: "T", left: "40%" }, { label: "G#4", key: "Y", left: "50%" },
  { label: "A#4", key: "U", left: "60%" }, { label: "C#5", key: "O", left: "80%" },
  { label: "D#5", key: "P", left: "90%" },
];

export function QuietKeysRefined() {
  const [octave, setOctave] = useState(4);
  const [active, setActive] = useState<string[]>([]);
  const [lastNote, setLastNote] = useState("—");
  const [volume, setVolume] = useState(72);
  const [started, setStarted] = useState(false);
  const allKeys = useMemo(() => [...whiteKeys, ...blackKeys], []);

  const play = (key: string, label: string) => {
    setStarted(true);
    setLastNote(label.replace("4", String(octave)));
    setActive((current) => current.includes(key) ? current : [...current, key]);
    window.setTimeout(() => setActive((current) => current.filter((item) => item !== key)), 360);
  };

  return (
    <main className="quiet-keys">
      <style>{`
        .quiet-keys{min-height:100vh;background:#eee7d8;color:#2d3037;font-family:Manrope,ui-sans-serif,sans-serif;padding:0 28px 34px;overflow:hidden}
        .quiet-keys *{box-sizing:border-box}.qk-shell{max-width:1240px;margin:auto}.qk-mono{font-family:"DM Mono",ui-monospace,monospace;letter-spacing:.14em;text-transform:uppercase}
        .qk-header{height:78px;border-bottom:1px solid rgba(45,48,55,.14);display:flex;align-items:center;justify-content:space-between}
        .qk-brand{display:flex;gap:12px;align-items:center}.qk-mark{width:35px;height:35px;border-radius:10px;background:#343945;color:#f1c45d;display:grid;place-items:center}
        .qk-brand-name{font-weight:800;font-size:14px;letter-spacing:-.04em}.qk-brand-meta{font-size:9px;color:#838078;margin-top:3px}
        .qk-status{display:flex;align-items:center;gap:8px;font-size:9px;color:#77736b}.qk-status i{width:6px;height:6px;border-radius:50%;background:#df6f42;display:block}.qk-status.live i{background:#43836d}
        .qk-hero{display:grid;grid-template-columns:1fr 280px;gap:50px;align-items:end;padding:68px 0 52px}.qk-kicker{font-size:10px;color:#ce643b;display:flex;align-items:center;gap:11px}.qk-kicker:before{content:"";width:32px;height:1px;background:#ce643b}
        .qk-title{font-family:"Playfair Display",Georgia,serif;font-size:clamp(48px,7vw,92px);line-height:.91;letter-spacing:-.075em;font-weight:500;margin:18px 0 23px}.qk-title em{color:#ce643b;font-style:italic}.qk-copy{font-size:14px;line-height:1.7;color:#77736b;max-width:445px}
        .qk-note{min-height:190px;border-radius:18px;background:#343945;color:#f1c45d;padding:19px 21px;position:relative;overflow:hidden;box-shadow:0 17px 34px rgba(45,48,55,.16)}.qk-note:after,.qk-note:before{content:"";position:absolute;border:1px solid rgba(241,196,93,.23);border-radius:50%;width:145px;height:145px;right:-55px;top:-48px}.qk-note:before{width:87px;height:87px;right:0;top:-18px}
        .qk-note-top{display:flex;justify-content:space-between;font-size:9px;color:rgba(241,196,93,.62)}.qk-note-top b{color:#e9a56e;font-weight:500}.qk-current{margin-top:60px;display:flex;align-items:baseline;gap:9px;position:relative}.qk-current strong{font:500 84px/.7 "Playfair Display",Georgia,serif;letter-spacing:-.1em}.qk-current span{font:12px "DM Mono",monospace;color:rgba(241,196,93,.6)}
        .qk-instrument{background:#f8f3ea;border:1px solid rgba(45,48,55,.13);border-radius:20px;padding:20px 20px 16px;box-shadow:0 11px 25px rgba(88,71,48,.08)}.qk-toolbar{display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid rgba(45,48,55,.12);padding:1px 5px 18px}.qk-label{font-size:10px;color:#817b72}.qk-range{font-weight:800;font-size:18px;letter-spacing:-.05em;margin-top:7px}.qk-controls{display:flex;gap:17px;align-items:center}.qk-volume{display:flex;align-items:center;gap:8px;color:#817b72}.qk-volume input{width:94px;accent-color:#ce643b}.qk-release{background:transparent;border:1px solid rgba(45,48,55,.14);border-radius:9px;padding:9px 11px;color:#817b72;cursor:pointer;font-size:9px}
        .qk-keyboard{height:225px;position:relative;display:grid;grid-template-columns:repeat(10,1fr);margin:20px 3px 18px;touch-action:none}.qk-key{cursor:pointer;user-select:none;position:relative;border:1px solid #c8bdaa;border-top-color:#fffdf8;background:linear-gradient(105deg,#f2ecdf,#fffdf8 45%,#e4dac9);box-shadow:inset 0 -13px 16px rgba(113,92,62,.08),0 4px 0 rgba(99,78,47,.28);transition:transform .1s,background .12s}.qk-key:first-child{border-radius:9px 0 0 9px}.qk-key:nth-child(10){border-radius:0 9px 9px 0}.qk-key:hover{background:#f9f0d8}.qk-key.on{transform:translateY(4px);background:#f5ce76;box-shadow:inset 0 -5px 10px rgba(153,91,27,.18),0 1px 0 rgba(99,78,47,.25)}.qk-key-label{position:absolute;bottom:29px;left:50%;transform:translateX(-50%);font:10px "DM Mono",monospace;color:#77736b}.qk-key-letter{position:absolute;bottom:10px;left:50%;transform:translateX(-50%);font:10px "DM Mono",monospace;color:#a09a8f}.qk-black{position:absolute;z-index:2;top:0;width:6.2%;height:61%;transform:translateX(-50%);border:1px solid #20232b;border-top-color:#626675;border-radius:0 0 7px 7px;background:linear-gradient(100deg,#292c35,#464b58 52%,#22252c);box-shadow:inset 3px 0 3px rgba(255,255,255,.08),0 6px 4px rgba(36,35,31,.35)}.qk-black:hover{background:#4a4e58}.qk-black.on{transform:translate(-50%,4px);background:#c75c38}.qk-black .qk-key-label{top:11px;bottom:auto;color:rgba(255,249,232,.72);font-size:9px}
        .qk-footbar{border-top:1px solid rgba(45,48,55,.12);padding:15px 5px 0;display:flex;justify-content:space-between;gap:12px;font-size:9px;color:#817b72}.qk-footbar b{color:#2d3037;font-weight:500}.qk-lower{display:grid;grid-template-columns:1fr 310px;gap:20px;margin-top:18px}.qk-card{border:1px solid rgba(45,48,55,.12);border-radius:17px;padding:20px;background:rgba(248,243,234,.52)}.qk-card h2{font:600 23px/1.08 "Playfair Display",Georgia,serif;margin:9px 0 9px;letter-spacing:-.05em}.qk-card p{font-size:13px;line-height:1.65;color:#817b72;max-width:520px;margin:0}.qk-shift{display:flex;align-items:center;justify-content:space-between;background:#e1d8c8}.qk-shift strong{font-size:15px}.qk-shift small{display:block;margin-top:5px;color:#817b72;font:9px "DM Mono",monospace;text-transform:uppercase;letter-spacing:.12em}.qk-arrows{display:flex;gap:7px}.qk-arrows button{width:38px;height:38px;border:1px solid rgba(45,48,55,.15);border-radius:10px;background:#f8f3ea;display:grid;place-items:center;color:#2d3037;cursor:pointer}.qk-arrows button:hover{color:#ce643b;border-color:#ce643b}
        @media(max-width:760px){.quiet-keys{padding:0 16px 25px}.qk-header{height:68px}.qk-status{font-size:8px}.qk-hero{grid-template-columns:1fr;gap:28px;padding:45px 0 34px}.qk-title{font-size:clamp(50px,16vw,76px)}.qk-note{min-height:160px}.qk-current{margin-top:40px}.qk-current strong{font-size:70px}.qk-toolbar{align-items:flex-start;gap:15px;flex-direction:column}.qk-controls{width:100%;justify-content:space-between}.qk-keyboard{height:190px;min-width:610px}.qk-instrument{overflow-x:auto}.qk-lower{grid-template-columns:1fr}.qk-footbar{flex-direction:column}.qk-copy{font-size:13px}}
      `}</style>
      <div className="qk-shell">
        <header className="qk-header">
          <div className="qk-brand"><div className="qk-mark"><Piano size={17} strokeWidth={1.8} /></div><div><div className="qk-brand-name">small piano room</div><div className="qk-brand-meta qk-mono">keys / 01</div></div></div>
          <div className={`qk-status ${started ? "live" : ""}`}><i />{started ? "room is listening" : "tap a key to begin"}</div>
        </header>
        <section className="qk-hero">
          <div><div className="qk-kicker qk-mono">A quiet place to practice</div><h1 className="qk-title">Find the note <em>before</em><br /> you find the word.</h1><p className="qk-copy">A focused browser piano for the five minutes between an idea and making it real. No account, no setup — just sound.</p></div>
          <aside className="qk-note"><div className="qk-note-top qk-mono"><span>current note</span><b>{started ? "live" : "idle"}</b></div><div className="qk-current"><strong>{lastNote.replace(/[0-9]/g, "")}</strong><span>{lastNote === "—" ? "" : lastNote.slice(-1)}</span></div></aside>
        </section>
        <section className="qk-instrument">
          <div className="qk-toolbar"><div><div className="qk-label qk-mono">The instrument · soft triangle</div><div className="qk-range">C{octave} — E{octave + 1}</div></div><div className="qk-controls"><label className="qk-volume"><Volume2 size={15} /><input aria-label="Volume" type="range" min="0" max="100" value={volume} onChange={(e) => setVolume(Number(e.target.value))} /></label><button className="qk-release" type="button" onClick={() => { setActive([]); setLastNote("—"); setStarted(false); }}><RotateCcw size={12} /> Release</button></div></div>
          <div className="qk-keyboard">{whiteKeys.map((item) => <button className={`qk-key ${active.includes(item.key) ? "on" : ""}`} key={item.key} type="button" onPointerDown={() => play(item.key, item.label)} aria-label={`Play ${item.label}`}><span className="qk-key-label">{item.label}</span><span className="qk-key-letter">{item.key}</span></button>)}{blackKeys.map((item) => <button className={`qk-key qk-black ${active.includes(item.key) ? "on" : ""}`} style={{ left: item.left }} key={item.key} type="button" onPointerDown={() => play(item.key, item.label)} aria-label={`Play ${item.label}`}><span className="qk-key-label">{item.key}</span></button>)}</div>
          <div className="qk-footbar qk-mono"><span><b>A S D F G H J K L ;</b> white keys <span>/</span> <b>W E T Y U O P</b> black keys</span><span><Headphones size={12} style={{ verticalAlign: "middle", marginRight: 7 }} /> press and hold to sustain</span></div>
        </section>
        <section className="qk-lower"><div className="qk-card"><div className="qk-label qk-mono">Pitch window</div><h2>Make a little room for listening.</h2><p>Start with middle C, then follow the shape of the keys. The amber flash is the note under your finger; the small letter is its computer-key twin.</p></div><div className="qk-card qk-shift"><div><div className="qk-label qk-mono">Move the room</div><strong>Octave {octave}</strong><small>range shift</small></div><div className="qk-arrows"><button type="button" aria-label="Lower octave" disabled={octave <= 2} onClick={() => setOctave((value) => Math.max(2, value - 1))}><ChevronLeft size={17} /></button><button type="button" aria-label="Raise octave" disabled={octave >= 6} onClick={() => setOctave((value) => Math.min(6, value + 1))}><ChevronRight size={17} /></button></div></div></section>
        <footer className="qk-footbar qk-mono" style={{ marginTop: 28 }}><span>Built for the in-between moments</span><span>Web Audio / 12-tone equal temperament</span></footer>
      </div>
    </main>
  );
}

export default QuietKeysRefined;