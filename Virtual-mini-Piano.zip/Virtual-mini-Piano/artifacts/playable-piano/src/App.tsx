import { useCallback, useEffect, useMemo, useRef, useState, type PointerEvent } from 'react';
import { ChevronLeft, ChevronRight, CircleHelp, Keyboard, Piano, RotateCcw, Volume2, VolumeX } from 'lucide-react';

type Voice = {
  oscillators: OscillatorNode[];
  gain: GainNode;
};

type PianoNote = {
  id: string;
  name: string;
  octave: number;
  midi: number;
  frequency: number;
  black: boolean;
  keyboard?: string;
  whiteIndex?: number;
};

const NOTE_NAMES = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
const KEYBOARD_MAP = ['a', 'w', 's', 'e', 'd', 'f', 't', 'g', 'y', 'h', 'u', 'j', 'k', 'o', 'l', 'p', ';'];
const KEY_LABELS: Record<string, string> = { ';': ';' };

function formatKey(key?: string) {
  if (!key) return '';
  return KEY_LABELS[key] ?? key.toUpperCase();
}

function createPianoNotes(octave: number): PianoNote[] {
  const baseMidi = octave * 12 + 12;
  const notes: PianoNote[] = [];
  let whiteIndex = 0;
  // Always render ten white keys with their seven matching black keys.
  for (let i = 0; i <= 16; i += 1) {
    const midi = baseMidi + i;
    const name = NOTE_NAMES[midi % 12];
    const note: PianoNote = {
      id: `${name}${Math.floor(midi / 12) - 1}`,
      name,
      octave: Math.floor(midi / 12) - 1,
      midi,
      frequency: 440 * Math.pow(2, (midi - 69) / 12),
      black: name.includes('#'),
      keyboard: KEYBOARD_MAP[i],
    };
    if (!note.black) {
      note.whiteIndex = whiteIndex;
      whiteIndex += 1;
    }
    notes.push(note);
  }
  return notes;
}

function Home() {
  const [octave, setOctave] = useState(4);
  const [volume, setVolume] = useState(0.72);
  const [activeKeys, setActiveKeys] = useState<string[]>([]);
  const [lastNote, setLastNote] = useState<PianoNote | null>(null);
  const [audioReady, setAudioReady] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const masterGainRef = useRef<GainNode | null>(null);
  const voicesRef = useRef<Map<string, Voice>>(new Map());
  const heldKeyboardRef = useRef<Set<string>>(new Set());
  const pointerNotesRef = useRef<Map<number, string>>(new Map());
  const notes = useMemo(() => createPianoNotes(octave), [octave]);
  const noteById = useMemo(() => new Map(notes.map((note) => [note.id, note])), [notes]);
  const whiteNotes = notes.filter((note) => !note.black);
  const blackNotes = notes.filter((note) => note.black);
  const currentRange = `${whiteNotes[0]?.name}${whiteNotes[0]?.octave} — ${whiteNotes[whiteNotes.length - 1]?.name}${whiteNotes[whiteNotes.length - 1]?.octave}`;

  const ensureAudio = useCallback(() => {
    if (!audioContextRef.current) {
      const context = new AudioContext();
      const master = context.createGain();
      master.gain.value = volume;
      master.connect(context.destination);
      audioContextRef.current = context;
      masterGainRef.current = master;
    }
    if (audioContextRef.current.state === 'suspended') {
      void audioContextRef.current.resume();
    }
    setAudioReady(true);
    return audioContextRef.current;
  }, [volume]);

  const releaseAll = useCallback(() => {
    voicesRef.current.forEach((voice) => {
      const context = audioContextRef.current;
      if (context) {
        voice.gain.gain.cancelScheduledValues(context.currentTime);
        voice.gain.gain.setTargetAtTime(0, context.currentTime, 0.045);
        voice.oscillators.forEach((oscillator) => oscillator.stop(context.currentTime + 0.24));
      }
    });
    voicesRef.current.clear();
    heldKeyboardRef.current.clear();
    pointerNotesRef.current.clear();
    setActiveKeys([]);
  }, []);

  const startNote = useCallback((note: PianoNote) => {
    if (voicesRef.current.has(note.id)) return;
    const context = ensureAudio();
    const now = context.currentTime;
    const noteGain = context.createGain();
    noteGain.gain.setValueAtTime(0.0001, now);
    noteGain.gain.exponentialRampToValueAtTime(0.72, now + 0.012);
    noteGain.gain.exponentialRampToValueAtTime(0.42, now + 0.18);

    const oscillatorA = context.createOscillator();
    const oscillatorB = context.createOscillator();
    oscillatorA.type = 'triangle';
    oscillatorB.type = 'sine';
    oscillatorA.frequency.value = note.frequency;
    oscillatorB.frequency.value = note.frequency * 2;
    const overtoneGain = context.createGain();
    overtoneGain.gain.value = 0.12;
    oscillatorA.connect(noteGain);
    oscillatorB.connect(overtoneGain);
    overtoneGain.connect(noteGain);
    noteGain.connect(masterGainRef.current!);
    oscillatorA.start(now);
    oscillatorB.start(now);
    voicesRef.current.set(note.id, { oscillators: [oscillatorA, oscillatorB], gain: noteGain });
    setActiveKeys((current) => (current.includes(note.id) ? current : [...current, note.id]));
    setLastNote(note);
  }, [ensureAudio]);

  const stopNote = useCallback((note: PianoNote) => {
    const voice = voicesRef.current.get(note.id);
    if (!voice) return;
    const context = audioContextRef.current;
    if (context) {
      const now = context.currentTime;
      voice.gain.gain.cancelScheduledValues(now);
      voice.gain.gain.setTargetAtTime(0.0001, now, 0.08);
      voice.oscillators.forEach((oscillator) => oscillator.stop(now + 0.32));
    }
    voicesRef.current.delete(note.id);
    setActiveKeys((current) => current.filter((id) => id !== note.id));
  }, []);

  useEffect(() => {
    if (masterGainRef.current) {
      masterGainRef.current.gain.setTargetAtTime(volume, audioContextRef.current?.currentTime ?? 0, 0.025);
    }
  }, [volume]);

  useEffect(() => {
    releaseAll();
  }, [octave, releaseAll]);

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) return;
      const key = event.key.toLowerCase();
      const mapIndex = KEYBOARD_MAP.indexOf(key);
      if (mapIndex < 0 || event.repeat || heldKeyboardRef.current.has(key)) return;
      const note = notes[mapIndex];
      if (!note) return;
      event.preventDefault();
      heldKeyboardRef.current.add(key);
      startNote(note);
    };
    const onKeyUp = (event: KeyboardEvent) => {
      const key = event.key.toLowerCase();
      const mapIndex = KEYBOARD_MAP.indexOf(key);
      if (mapIndex < 0) return;
      heldKeyboardRef.current.delete(key);
      const note = notes[mapIndex];
      if (note) stopNote(note);
    };
    const onBlur = () => releaseAll();
    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);
    window.addEventListener('blur', onBlur);
    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      window.removeEventListener('blur', onBlur);
    };
  }, [notes, releaseAll, startNote, stopNote]);

  const handlePointerDown = (event: PointerEvent<HTMLButtonElement>, note: PianoNote) => {
    event.preventDefault();
    event.currentTarget.setPointerCapture(event.pointerId);
    pointerNotesRef.current.set(event.pointerId, note.id);
    startNote(note);
  };

  const handlePointerUp = (event: PointerEvent<HTMLButtonElement>) => {
    const noteId = pointerNotesRef.current.get(event.pointerId);
    if (noteId) {
      const note = noteById.get(noteId);
      if (note) stopNote(note);
    }
    pointerNotesRef.current.delete(event.pointerId);
  };

  const changeOctave = (delta: number) => {
    setOctave((current) => Math.min(6, Math.max(2, current + delta)));
  };

  return (
    <main className="room-grain min-h-[100dvh] overflow-hidden bg-background">
      <div className="mx-auto min-h-[100dvh] w-full max-w-[1440px] px-5 pb-10 sm:px-8 lg:px-12">
        <header className="flex items-center justify-between border-b border-foreground/10 py-5 sm:py-7">
          <div className="flex items-center gap-3">
            <div className="flex h-9 w-9 items-center justify-center rounded-[11px] bg-secondary text-accent shadow-sm">
              <Piano size={18} strokeWidth={1.8} />
            </div>
            <div>
              <p className="font-mono-ui text-[10px] font-medium uppercase tracking-[0.19em] text-muted-foreground">Keys / 01</p>
              <p className="mt-0.5 text-sm font-extrabold tracking-[-0.03em] text-foreground">small piano room</p>
            </div>
          </div>
          <div className="flex items-center gap-2 rounded-full border border-foreground/10 bg-card/55 px-3 py-2">
            <span className={`h-1.5 w-1.5 rounded-full ${audioReady ? 'bg-[#45806c]' : 'bg-primary'}`} />
            <span className="font-mono-ui text-[9px] uppercase tracking-[0.14em] text-muted-foreground">
              {audioReady ? 'room is listening' : 'tap a key to begin'}
            </span>
          </div>
        </header>

        <section className="animate-entrance grid gap-10 pb-9 pt-10 sm:pt-14 lg:grid-cols-[minmax(0,1fr)_250px] lg:items-end lg:gap-16 lg:pb-12">
          <div>
            <div className="mb-5 flex items-center gap-3">
              <span className="h-px w-9 bg-primary" />
              <span className="font-mono-ui text-[10px] uppercase tracking-[0.19em] text-primary">A quiet place to practice</span>
            </div>
            <h1 className="max-w-[680px] text-[clamp(2.65rem,7vw,6.1rem)] font-medium leading-[0.94] tracking-[-0.065em] text-foreground">
              Find the note
              <span className="font-display italic text-primary"> before</span>
              <br className="hidden sm:block" /> you find the word.
            </h1>
            <p className="mt-6 max-w-[480px] text-sm leading-6 text-muted-foreground sm:text-[15px]">
              A focused browser piano for the five minutes between an idea and making it real. No account, no setup — just sound.
            </p>
          </div>

          <div className="relative flex min-h-[152px] flex-col justify-between overflow-hidden rounded-2xl border border-foreground/10 bg-secondary p-5 text-secondary-foreground shadow-lg sm:min-h-[180px] sm:p-6">
            <div className="absolute -right-8 -top-10 h-32 w-32 rounded-full border border-accent/25" />
            <div className="absolute -right-1 -top-3 h-20 w-20 rounded-full border border-accent/20" />
            <div className="relative flex items-center justify-between">
              <span className="font-mono-ui text-[9px] uppercase tracking-[0.18em] text-secondary-foreground/55">Current note</span>
              <span className="font-mono-ui text-[9px] uppercase tracking-[0.18em] text-accent">{audioReady ? 'live' : 'idle'}</span>
            </div>
            <div className={`relative mt-5 flex items-end gap-3 ${lastNote ? 'animate-note-pulse' : ''}`}>
              <span data-testid="text-current-note" className="font-display text-[5.2rem] font-medium leading-[0.8] tracking-[-0.08em] text-accent sm:text-[6.3rem]">
                {lastNote?.name ?? '—'}
              </span>
              <span data-testid="text-current-octave" className="mb-1 font-mono-ui text-sm text-secondary-foreground/65">
                {lastNote?.octave ?? ''}
              </span>
            </div>
          </div>
        </section>

        <section className="animate-entrance rounded-[1.35rem] border border-foreground/10 bg-card/75 p-3 shadow-md [animation-delay:120ms] sm:p-5 lg:p-6">
          <div className="flex flex-col gap-5 border-b border-foreground/10 px-2 pb-5 sm:flex-row sm:items-center sm:justify-between sm:px-3">
            <div>
              <div className="flex items-center gap-2">
                <span className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">The instrument</span>
                <span className="rounded-full bg-muted px-2 py-1 font-mono-ui text-[9px] uppercase tracking-[0.12em] text-muted-foreground">soft triangle</span>
              </div>
              <p data-testid="text-current-range" className="mt-2 text-lg font-bold tracking-[-0.04em] text-foreground">{currentRange}</p>
            </div>
            <div className="flex items-center justify-between gap-5 sm:justify-end">
              <label className="flex items-center gap-2.5">
                {volume === 0 ? <VolumeX size={15} className="text-muted-foreground" /> : <Volume2 size={15} className="text-muted-foreground" />}
                <input
                  aria-label="Volume"
                  data-testid="input-volume"
                  type="range"
                  min="0"
                  max="1"
                  step="0.01"
                  value={volume}
                  onChange={(event) => setVolume(Number(event.target.value))}
                  className="h-1 w-24 cursor-pointer sm:w-28"
                />
              </label>
              <button
                type="button"
                data-testid="button-release-all"
                onClick={releaseAll}
                className="flex items-center gap-2 rounded-lg border border-foreground/10 px-3 py-2 font-mono-ui text-[9px] uppercase tracking-[0.12em] text-muted-foreground transition-colors hover:bg-muted hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <RotateCcw size={12} />
                Release
              </button>
            </div>
          </div>

          <div className="mt-5 overflow-x-auto pb-3 [scrollbar-color:hsl(var(--primary))_transparent]">
            <div className="relative mx-auto h-[190px] w-full max-w-[1100px] px-1 sm:h-[225px]">
              <div className="grid h-full grid-cols-10">
                {whiteNotes.map((note) => (
                  <button
                    key={note.id}
                    type="button"
                    aria-label={`Play ${note.name}${note.octave}`}
                    data-testid={`piano-key-${note.id}`}
                    className={`piano-key piano-key-white ${activeKeys.includes(note.id) ? 'is-active' : ''}`}
                    onPointerDown={(event) => handlePointerDown(event, note)}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerUp}
                    onLostPointerCapture={handlePointerUp}
                  >
                    <span className="key-caption">{note.name}{note.octave}</span>
                    {note.keyboard && <span className="absolute bottom-1.5 left-1/2 -translate-x-1/2 font-mono-ui text-[9px] font-medium text-foreground/50">{formatKey(note.keyboard)}</span>}
                  </button>
                ))}
              </div>
              {blackNotes.map((note) => {
                const precedingWhite = notes.slice(0, notes.indexOf(note)).filter((item) => !item.black).length;
                return (
                  <button
                    key={note.id}
                    type="button"
                    aria-label={`Play ${note.name}${note.octave}`}
                    data-testid={`piano-key-${note.id}`}
                    className={`piano-key piano-key-black ${activeKeys.includes(note.id) ? 'is-active' : ''}`}
                    style={{ left: `${(precedingWhite / whiteNotes.length) * 100}%`, width: `${Math.max(30, 100 / whiteNotes.length * 0.62)}px` }}
                    onPointerDown={(event) => handlePointerDown(event, note)}
                    onPointerUp={handlePointerUp}
                    onPointerCancel={handlePointerUp}
                    onLostPointerCapture={handlePointerUp}
                  >
                    <span className="key-caption">{note.keyboard ? formatKey(note.keyboard) : note.name}</span>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="flex flex-col gap-3 border-t border-foreground/10 px-2 pt-4 sm:flex-row sm:items-center sm:justify-between sm:px-3">
            <div className="flex items-center gap-3">
              <Keyboard size={14} className="text-primary" />
              <p className="font-mono-ui text-[10px] uppercase tracking-[0.12em] text-muted-foreground">
                <span className="text-foreground">A S D F G H J K L ;</span> white keys <span className="mx-1 text-foreground/30">/</span> <span className="text-foreground">W E T Y U O P</span> black keys
              </p>
            </div>
            <p className="font-mono-ui text-[10px] uppercase tracking-[0.12em] text-muted-foreground">press and hold to sustain</p>
          </div>
        </section>

        <section className="animate-entrance mt-5 grid gap-5 [animation-delay:220ms] md:grid-cols-[minmax(0,1fr)_minmax(260px,350px)]">
          <div className="rounded-2xl border border-foreground/10 bg-card/45 p-5 sm:p-6">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Pitch window</p>
                <h2 className="mt-2 text-xl font-extrabold tracking-[-0.05em] text-foreground">Make a little room for listening.</h2>
              </div>
              <div className="mt-1 hidden h-9 w-9 items-center justify-center rounded-full border border-foreground/10 text-primary sm:flex">
                <CircleHelp size={16} strokeWidth={1.7} />
              </div>
            </div>
            <p className="mt-3 max-w-[590px] text-sm leading-6 text-muted-foreground">
              Start with middle C, then follow the shape of the keys. The orange flash is the note under your finger; the small letter is its computer-key twin.
            </p>
          </div>
          <div className="flex items-center justify-between rounded-2xl border border-foreground/10 bg-muted/70 p-5 sm:p-6">
            <div>
              <p className="font-mono-ui text-[10px] uppercase tracking-[0.18em] text-muted-foreground">Move the room</p>
              <p className="mt-2 text-sm font-bold text-foreground">Octave {octave}</p>
              <p className="mt-1 font-mono-ui text-[10px] text-muted-foreground">range shift</p>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                aria-label="Lower octave"
                data-testid="button-octave-down"
                disabled={octave <= 2}
                onClick={() => changeOctave(-1)}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-foreground/10 bg-card text-foreground transition-all hover:border-primary/50 hover:text-primary disabled:cursor-not-allowed disabled:opacity-35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <ChevronLeft size={17} />
              </button>
              <button
                type="button"
                aria-label="Raise octave"
                data-testid="button-octave-up"
                disabled={octave >= 6}
                onClick={() => changeOctave(1)}
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-foreground/10 bg-card text-foreground transition-all hover:border-primary/50 hover:text-primary disabled:cursor-not-allowed disabled:opacity-35 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary"
              >
                <ChevronRight size={17} />
              </button>
            </div>
          </div>
        </section>

        <footer className="flex flex-col gap-2 border-t border-foreground/10 pb-1 pt-7 sm:flex-row sm:items-center sm:justify-between">
          <p className="font-mono-ui text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Built for the in-between moments</p>
          <p className="font-mono-ui text-[9px] uppercase tracking-[0.16em] text-muted-foreground">Web Audio / 12-tone equal temperament</p>
        </footer>
      </div>
    </main>
  );
}

export default Home;