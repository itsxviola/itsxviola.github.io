import warmRoom from '@assets/targeted_element_1787089755057.png';

export default function PlayablePianoTitle() {
  return (
    <div className="relative h-screen w-screen overflow-hidden bg-[#0c080f]">
      <img
        src={warmRoom}
        alt="Warm listening room piano design"
        crossOrigin="anonymous"
        className="absolute inset-0 h-full w-full object-cover"
      />
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(12,8,15,0.05)_25%,rgba(12,8,15,0.88)_100%)]" />
      <div className="absolute right-[6vw] top-[4vh] font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
        Vol. I
      </div>
      <div className="absolute right-[6vw] top-1/2 z-10 flex w-[47vw] -translate-y-1/2 flex-col items-end text-right">
        <div className="mb-[3vh] flex items-center gap-[1.5vw] font-body text-[1.2vw] tracking-[0.2em] text-[#9b8bb4]">
          <span> SOUND &amp; VISION </span>
          <span className="text-[#c4a060]">—</span>
          <span> STUDIO SESSION </span>
        </div>
        <h1 className="max-w-[45vw] font-display text-[6vw] font-semibold leading-[1.05] tracking-[-0.02em] text-[#f0ece4]">
          Playable piano
        </h1>
        <div className="my-[4vh] h-[0.2vh] w-[8vw] bg-[#c4a060]" />
        <p className="max-w-[40vw] font-display text-[1.8vw] italic leading-[1.45] text-[#9b8bb4]">
          A small playable piano in the browser for creating melodies and learning notes.
        </p>
      </div>
      <div className="absolute bottom-[4vh] right-[6vw] font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
        WARM LISTENING ROOM
      </div>
    </div>
  );
}