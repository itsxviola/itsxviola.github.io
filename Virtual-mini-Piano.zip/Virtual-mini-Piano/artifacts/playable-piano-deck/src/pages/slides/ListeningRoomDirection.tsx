import warmRoom from '@assets/targeted_element_1787089755057.png';

export default function ListeningRoomDirection() {
  return (
    <div className="relative flex h-screen w-screen overflow-hidden bg-[#0c080f]">
      <div className="absolute left-1/2 top-0 h-full w-px bg-[rgba(155,139,180,0.12)]" />
      <div className="absolute left-0 top-1/2 h-px w-full bg-[rgba(155,139,180,0.12)]" />
      <div className="relative z-10 w-[50%] px-[6vw] py-[8vh]">
        <div className="mb-[8vh] font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          VISUAL LANGUAGE <span className="px-[1vw] text-[#c4a060]">—</span> WARM LISTENING ROOM
        </div>
        <h2 className="max-w-[36vw] font-display text-[4.4vw] font-semibold leading-[1.08] tracking-[-0.02em] text-[#f0ece4]">
          The listening-room direction
        </h2>
        <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
        <div className="flex max-w-[38vw] flex-col gap-[2.4vh] font-body text-[1.45vw] leading-[1.35] text-[#f0ece4]">
          <p>Warm clay, oat, walnut, and honey tones</p>
          <p>Paper-like instrument surfaces and tactile key shadows</p>
          <p>Editorial serif headlines paired with compact mono labels</p>
          <p>A dark current-note card creates contrast and focus</p>
        </div>
      </div>
      <div className="relative h-full w-[50%] p-[6vw] pl-[2vw]">
        <div className="absolute right-[6vw] top-[8vh] font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          03
        </div>
        <div className="absolute bottom-[10vh] left-[2vw] right-[6vw] top-[18vh] overflow-hidden border border-[rgba(196,160,96,0.45)] bg-[#211620] p-[0.8vw]">
          <img
            src={warmRoom}
            alt="Selected Warm Listening Room design"
            crossOrigin="anonymous"
            className="h-full w-full object-cover opacity-90"
          />
          <div className="absolute inset-0 bg-[linear-gradient(to_top,rgba(12,8,15,0.65),transparent_55%)]" />
          <div className="absolute bottom-[2vh] left-[2vw] font-display text-[1.5vw] italic text-[#f0ece4]">
            Warm Listening Room
          </div>
        </div>
      </div>
    </div>
  );
}