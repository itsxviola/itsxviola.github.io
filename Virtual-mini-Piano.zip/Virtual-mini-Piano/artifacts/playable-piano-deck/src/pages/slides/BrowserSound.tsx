export default function BrowserSound() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute left-0 top-0 h-full w-[44vw] bg-[radial-gradient(circle_at_20%_40%,rgba(196,160,96,0.16),transparent_62%)]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="mb-[5vh] flex justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div>SOUND <span className="px-[1vw] text-[#c4a060]">—</span> WEB AUDIO</div>
          <div>Vol. I</div>
        </div>
        <div className="flex flex-1 items-center justify-center">
          <div className="relative mr-[7vw] w-[38vw]">
            <div className="absolute -left-[4vw] top-[5vh] h-[22vw] w-[22vw] rounded-full border border-[rgba(196,160,96,0.35)]" />
            <div className="relative">
              <div className="font-body text-[1vw] tracking-[0.18em] text-[#c4a060]">SOUND THAT STARTS</div>
              <h2 className="mt-[2vh] font-display text-[4.7vw] font-semibold leading-[1.04] tracking-[-0.02em] text-[#f0ece4]">
                Sound that starts in the browser
              </h2>
              <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
              <p className="max-w-[31vw] font-display text-[1.9vw] italic leading-[1.45] text-[#9b8bb4]">
                Immediate response, with no instrument between the idea and the sound.
              </p>
            </div>
          </div>
          <div className="w-[38vw] border-l border-[rgba(155,139,180,0.28)] pl-[4vw]">
            <div className="flex flex-col gap-[3vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              <p><span className="mr-[1.2vw] text-[#c4a060]">01</span> Web Audio API synthesis keeps response immediate</p>
              <p><span className="mr-[1.2vw] text-[#c4a060]">02</span> The first interaction unlocks audio gracefully</p>
              <p><span className="mr-[1.2vw] text-[#c4a060]">03</span> Volume controls the live master gain</p>
              <p><span className="mr-[1.2vw] text-[#c4a060]">04</span> Sustain lets notes remain active until release or reset</p>
              <p><span className="mr-[1.2vw] text-[#c4a060]">05</span> Release clears active voices and returns the room to idle</p>
            </div>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>06</span>
          <span>WEB AUDIO / SYNTHESIS</span>
        </div>
      </div>
    </div>
  );
}