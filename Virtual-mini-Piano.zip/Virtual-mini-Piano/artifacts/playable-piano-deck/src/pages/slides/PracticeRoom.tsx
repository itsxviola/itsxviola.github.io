export default function PracticeRoom() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute -right-[10vw] -top-[18vh] h-[42vw] w-[42vw] rounded-full bg-[radial-gradient(circle,rgba(155,139,180,0.08)_0%,transparent_68%)]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="mb-[8vh] flex items-start justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div className="flex items-center gap-[1.5vw]">
            <span>A SOFTER PLACE</span>
            <span className="text-[#c4a060]">—</span>
            <span>ARRIVE &amp; PLAY</span>
          </div>
          <span>Vol. I</span>
        </div>
        <div className="grid flex-1 grid-cols-[38%_1fr] gap-[8vw]">
          <div>
            <h2 className="font-display text-[4.5vw] font-semibold leading-[1.08] tracking-[-0.02em] text-[#f0ece4]">
              A softer place to practice
            </h2>
            <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
            <p className="max-w-[30vw] font-display text-[1.9vw] italic leading-[1.45] text-[#9b8bb4]">
              The space between hearing an idea and giving it shape.
            </p>
          </div>
          <div className="flex flex-col justify-center gap-[5vh]">
            <div className="flex gap-[2vw]">
              <span className="font-body text-[1.2vw] text-[#c4a060]">01</span>
              <p className="max-w-[34vw] font-body text-[1.9vw] leading-[1.45] text-[#f0ece4]">
                The project turns a browser tab into a focused piano room
              </p>
            </div>
            <div className="flex gap-[2vw]">
              <span className="font-body text-[1.2vw] text-[#c4a060]">02</span>
              <p className="max-w-[34vw] font-body text-[1.9vw] leading-[1.45] text-[#f0ece4]">
                No account, no setup, no distractions
              </p>
            </div>
            <div className="flex gap-[2vw]">
              <span className="font-body text-[1.2vw] text-[#c4a060]">03</span>
              <p className="max-w-[34vw] font-body text-[1.9vw] leading-[1.45] text-[#f0ece4]">
                The experience is designed around the space between hearing an idea and giving it shape
              </p>
            </div>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>02</span>
          <span>PLAYABLE PIANO</span>
        </div>
      </div>
    </div>
  );
}