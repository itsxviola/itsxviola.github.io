export default function UsableEverywhere() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute bottom-0 right-0 h-[62vh] w-[46vw] bg-[linear-gradient(135deg,transparent,rgba(155,139,180,0.1))]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="flex justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div>ACCESS <span className="px-[1vw] text-[#c4a060]">—</span> RESPONSIVE EXPERIENCE</div>
          <div>Vol. I</div>
        </div>
        <div className="mt-[7vh] flex flex-1 items-center gap-[9vw]">
          <div className="w-[42%]">
            <div className="mb-[2vh] font-body text-[1.1vw] tracking-[0.18em] text-[#c4a060]">07 / RESPONSIVE EXPERIENCE</div>
            <h2 className="font-display text-[5vw] font-semibold leading-[1.02] tracking-[-0.03em] text-[#f0ece4]">
              Designed to stay usable
            </h2>
            <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
            <p className="max-w-[31vw] font-display text-[1.9vw] italic leading-[1.45] text-[#9b8bb4]">
              The full instrument remains the focus, whatever the screen.
            </p>
          </div>
          <div className="w-[43%] border-t border-[#c4a060] pt-[2vh]">
            <div className="flex flex-col gap-[2.8vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              <p>The full 17-key keyboard remains usable on mobile</p>
              <p>Responsive layout preserves the instrument as the primary focus</p>
              <p>Visible labels explain the computer-key mapping</p>
              <p>Focus states support keyboard navigation</p>
              <p>Reduced-motion preferences are respected</p>
            </div>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>07</span>
          <span>RESPONSIVE / FOCUS</span>
        </div>
      </div>
    </div>
  );
}