export default function CompactInstrument() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute bottom-[-15vw] left-[-8vw] h-[40vw] w-[40vw] rounded-full border border-[rgba(155,139,180,0.12)]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="flex items-start justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div>A COMPACT INSTRUMENT <span className="px-[1vw] text-[#c4a060]">—</span> RANGE &amp; MAPPING</div>
          <div>Vol. I</div>
        </div>
        <div className="mt-[8vh] grid flex-1 grid-cols-[42%_1fr] gap-[7vw]">
          <div>
            <h2 className="font-display text-[4.5vw] font-semibold leading-[1.05] tracking-[-0.02em] text-[#f0ece4]">
              A compact 17-key instrument
            </h2>
            <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
            <p className="max-w-[28vw] font-display text-[1.9vw] italic leading-[1.45] text-[#9b8bb4]">
              Small enough to keep the full range in view.
            </p>
          </div>
          <div className="flex flex-col justify-center gap-[3vh]">
            <div className="flex items-center gap-[2vw] border-b border-[rgba(155,139,180,0.25)] pb-[2.5vh]">
              <span className="font-display text-[3.5vw] text-[#c4a060]">10 + 7</span>
              <span className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Ten white keys plus seven matching black keys</span>
            </div>
            <div className="flex items-center gap-[2vw] border-b border-[rgba(155,139,180,0.25)] pb-[2.5vh]">
              <span className="font-display text-[3.5vw] text-[#c4a060]">C4–E5</span>
              <span className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Default range: C4 through E5</span>
            </div>
            <div className="flex items-center gap-[2vw] border-b border-[rgba(155,139,180,0.25)] pb-[2.5vh]">
              <span className="w-[10vw] font-body text-[1.25vw] tracking-[0.08em] text-[#c4a060]">A S D F G H J K L ;</span>
              <span className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">White-key mapping</span>
            </div>
            <div className="flex items-center gap-[2vw] border-b border-[rgba(155,139,180,0.25)] pb-[2.5vh]">
              <span className="w-[10vw] font-body text-[1.25vw] tracking-[0.08em] text-[#c4a060]">W E T Y U O P</span>
              <span className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Black-key mapping</span>
            </div>
            <div className="flex items-center gap-[2vw]">
              <span className="font-display text-[3.5vw] text-[#c4a060]">±</span>
              <span className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Octave shifting keeps the room playable across a wider register</span>
            </div>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>04</span>
          <span>RANGE / MAPPING</span>
        </div>
      </div>
    </div>
  );
}