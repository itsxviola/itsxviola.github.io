export default function GestureToNote() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute right-0 top-0 h-full w-[35vw] bg-[linear-gradient(135deg,rgba(155,139,180,0.1),transparent_65%)]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="mb-[7vh] flex justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div>INTERACTION <span className="px-[1vw] text-[#c4a060]">—</span> INPUT &amp; FEEDBACK</div>
          <div>Vol. I</div>
        </div>
        <div className="flex flex-1 items-center gap-[8vw]">
          <div className="w-[38%]">
            <h2 className="font-display text-[4.6vw] font-semibold leading-[1.04] tracking-[-0.02em] text-[#f0ece4]">
              Every gesture becomes a note
            </h2>
            <div className="my-[4vh] h-[0.2vh] w-[4vw] bg-[#c4a060]" />
            <p className="font-display text-[1.9vw] italic leading-[1.45] text-[#9b8bb4]">
              The hand, the key, and the sound stay in the same moment.
            </p>
          </div>
          <div className="grid w-[52%] grid-cols-2 gap-x-[3vw] gap-y-[5vh]">
            <div className="border-t border-[#c4a060] pt-[1.5vh]">
              <div className="mb-[1vh] font-body text-[1vw] tracking-[0.16em] text-[#c4a060]">01 / INPUT</div>
              <p className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Mouse and touch input press and release individual keys</p>
            </div>
            <div className="border-t border-[#c4a060] pt-[1.5vh]">
              <div className="mb-[1vh] font-body text-[1vw] tracking-[0.16em] text-[#c4a060]">02 / LAYOUT</div>
              <p className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Computer-keyboard input mirrors the physical layout</p>
            </div>
            <div className="border-t border-[#c4a060] pt-[1.5vh]">
              <div className="mb-[1vh] font-body text-[1vw] tracking-[0.16em] text-[#c4a060]">03 / HOLD</div>
              <p className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Repeated keydown events do not retrigger held notes</p>
            </div>
            <div className="border-t border-[#c4a060] pt-[1.5vh]">
              <div className="mb-[1vh] font-body text-[1vw] tracking-[0.16em] text-[#c4a060]">04 / STATE</div>
              <p className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Pressed keys animate, glow, and update the current-note display</p>
            </div>
            <div className="col-span-2 border-t border-[#c4a060] pt-[1.5vh]">
              <div className="mb-[1vh] font-body text-[1vw] tracking-[0.16em] text-[#c4a060]">05 / SAFETY</div>
              <p className="font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">Window blur releases held notes safely</p>
            </div>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>05</span>
          <span>GESTURE / NOTE</span>
        </div>
      </div>
    </div>
  );
}