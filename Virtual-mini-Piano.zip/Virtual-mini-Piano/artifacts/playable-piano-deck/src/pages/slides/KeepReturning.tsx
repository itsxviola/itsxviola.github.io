export default function KeepReturning() {
  return (
    <div className="relative flex h-screen w-screen flex-col overflow-hidden bg-[#0c080f] px-[6vw] py-[8vh]">
      <div className="absolute left-1/2 top-0 h-full w-px bg-[rgba(155,139,180,0.12)]" />
      <div className="absolute left-0 top-1/2 h-px w-full bg-[rgba(155,139,180,0.12)]" />
      <div className="relative z-10 flex h-full flex-col">
        <div className="flex justify-between font-body text-[1vw] tracking-[0.2em] text-[#9b8bb4]">
          <div>THE ROOM <span className="px-[1vw] text-[#c4a060]">—</span> CLOSING NOTE</div>
          <div>Vol. I</div>
        </div>
        <div className="flex flex-1 flex-col items-center justify-center text-center">
          <div className="mb-[3vh] font-body text-[1.1vw] tracking-[0.2em] text-[#c4a060]">A ROOM TO RETURN TO</div>
          <h2 className="max-w-[68vw] font-display text-[5.8vw] font-semibold leading-[1.02] tracking-[-0.03em] text-[#f0ece4]">
            A room you can keep returning to
          </h2>
          <div className="my-[4vh] h-[0.2vh] w-[6vw] bg-[#c4a060]" />
          <div className="grid w-[76vw] grid-cols-2 gap-x-[7vw] gap-y-[3vh] text-left">
            <p className="border-t border-[rgba(155,139,180,0.35)] pt-[1.4vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              The core experience is functional and self-contained
            </p>
            <p className="border-t border-[rgba(155,139,180,0.35)] pt-[1.4vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              Visual feedback makes practice feel tactile, not clinical
            </p>
            <p className="border-t border-[rgba(155,139,180,0.35)] pt-[1.4vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              The selected warm direction gives the piano a distinct emotional identity
            </p>
            <p className="border-t border-[rgba(155,139,180,0.35)] pt-[1.4vh] font-body text-[1.8vw] leading-[1.35] text-[#f0ece4]">
              Next opportunity: evolve the room with additional sound presets while keeping the interface quiet
            </p>
          </div>
        </div>
        <div className="flex justify-between font-body text-[1vw] tracking-[0.1em] text-[#9b8bb4]">
          <span>08</span>
          <span>PLAYABLE PIANO</span>
        </div>
      </div>
    </div>
  );
}