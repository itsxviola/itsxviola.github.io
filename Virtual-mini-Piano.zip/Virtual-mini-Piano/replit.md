# Playable Piano

A focused browser piano that plays accurate notes from mouse, touch, or computer-keyboard input with tactile visual feedback.

## Run & Operate

- `pnpm --filter @workspace/api-server run dev` — run the API server (port 5000)
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- Required env: `DATABASE_URL` — Postgres connection string

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/playable-piano/src/App.tsx` — piano interaction, Web Audio synthesis, note mapping, and page composition
- `artifacts/playable-piano/src/index.css` — visual theme, responsive piano styling, key states, and motion
- `artifacts/api-server` — shared API scaffold, not required by the piano

## Architecture decisions

- Audio is synthesized in the browser with Web Audio API so notes respond immediately without a server round trip.
- Mouse, touch, and physical keyboard input share the same note lifecycle so pressed-state visuals and audio stay synchronized.
- The app is intentionally frontend-only; it has no accounts, persistence, or backend dependency.

## Product

- Play a compact piano with mouse or touch.
- Play mapped notes with the computer keyboard.
- See the current note, octave, active key glow, and pressed-key animation.
- Shift the visible keyboard range and release all active notes.

## User preferences

_Populate as you build — explicit user instructions worth remembering across sessions._

## Gotchas

- Browsers require an interaction before audio can start; the first key press unlocks the audio context gracefully.
- The artifact workflow supplies `PORT` and `BASE_PATH`; use the managed workflow for previews.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
